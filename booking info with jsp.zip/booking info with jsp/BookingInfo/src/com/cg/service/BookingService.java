package com.cg.service;

import java.util.List;

import com.cg.entities.FlightBookEntity;



public interface BookingService 
{
	
	public int cancelbookingdetails( int  booking_Id);
	public List<FlightBookEntity> viewbookingdetails(int booking_Id);
    public abstract List<FlightBookEntity> loadAll();
	public FlightBookEntity booking(FlightBookEntity fbe);
	

}
