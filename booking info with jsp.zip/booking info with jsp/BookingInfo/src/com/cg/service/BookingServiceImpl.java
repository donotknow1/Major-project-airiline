package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BookingDao;
import com.cg.entities.FlightBookEntity;


@Service
@Transactional
public class BookingServiceImpl implements BookingService {
	@Autowired
	private BookingDao bookingDao;



	@Override
	public int cancelbookingdetails(int booking_Id) {
	
		return bookingDao.cancelbookingdetails(booking_Id);
	}



	@Override
	public  List<FlightBookEntity> viewbookingdetails(int booking_Id) {
		return bookingDao.viewbookingdetails(booking_Id);
			
		}



	@Override
	public List<FlightBookEntity> loadAll() {
		return bookingDao.loadAll();
	}



	@Override
	public FlightBookEntity booking(FlightBookEntity fbe) {
		return bookingDao.booking(fbe);
	}
	




	

	





	



}
