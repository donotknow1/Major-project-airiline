package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="BOOKING_INFO")
public class FlightBookEntity implements Serializable{
	/*BOOKING_ID                                         VARCHAR2(5)
	 CUST_EMAIL                                         VARCHAR2(20)
	 NO_OF_PASSENGERS                                   NUMBER
	 CLASS_TYPE                                         VARCHAR2(10)
	 TOTAL_FARE                                         NUMBER
	 SEAT                                               NUMBER
	 CREDIT_CARD_INFO                                   VARCHAR2(10)
	 SRC_CITY                                           VARCHAR2(10)
	 DEST_CITY                                          VARCHAR2(10)*/
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int booking_Id;
private String cust_Email;
private int no_Of_Passengers;
private String class_Type;
private int total_Fare;
private int seat;
private String credit_Card_Info;
private String src_City;
private String dest_City;
public int getBooking_Id() {
	return booking_Id;
}
public void setBooking_Id(int booking_Id) {
	this.booking_Id = booking_Id;
}
public String getCust_Email() {
	return cust_Email;
}
public void setCust_Email(String cust_Email) {
	this.cust_Email = cust_Email;
}
public int getNo_Of_Passengers() {
	return no_Of_Passengers;
}
public void setNo_Of_Passengers(int no_Of_Passengers) {
	this.no_Of_Passengers = no_Of_Passengers;
}
public String getClass_Type() {
	return class_Type;
}
public void setClass_Type(String class_Type) {
	this.class_Type = class_Type;
}
public int getTotal_Fare() {
	return total_Fare;
}
public void setTotal_Fare(int total_Fare) {
	this.total_Fare = total_Fare;
}
public int getSeat() {
	return seat;
}
public void setSeat(int seat) {
	this.seat = seat;
}
public String getCredit_Card_Info() {
	return credit_Card_Info;
}
public void setCredit_Card_Info(String credit_Card_Info) {
	this.credit_Card_Info = credit_Card_Info;
}
public String getSrc_City() {
	return src_City;
}
public void setSrc_City(String src_City) {
	this.src_City = src_City;
}
public String getDest_City() {
	return dest_City;
}
public void setDest_City(String dest_City) {
	this.dest_City = dest_City;
}



}
