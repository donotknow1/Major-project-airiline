package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.FlightBookEntity;

@Repository
public class BookingDaoImpl implements BookingDao {
	@PersistenceContext
	private EntityManager entityManager;
	
	

	@Override
	public int cancelbookingdetails(int booking_Id) {
		FlightBookEntity user=null;
		user=entityManager.find(FlightBookEntity.class, booking_Id);
		
		if(user!=null)
		{
			entityManager.remove(user);
			return booking_Id; 
		}
	return 0;
		
	}



	@Override
	public  List<FlightBookEntity> viewbookingdetails(int booking_id) {
		String query="SELECT r FROM  FlightBookEntity r WHERE r.booking_Id= :bId";
		TypedQuery<FlightBookEntity> getQuery = entityManager.createQuery(query,FlightBookEntity.class );
		getQuery.setParameter("bId", booking_id);
		return getQuery.getResultList();
	}



	@Override
	public List<FlightBookEntity> loadAll() {
		TypedQuery<FlightBookEntity>query=entityManager.createQuery("SELECT e FROM FlightBookEntity e",FlightBookEntity.class);
		return query.getResultList();
	}
	



	@Override
	public FlightBookEntity booking(FlightBookEntity fbe) {
		entityManager.persist(fbe);
		entityManager.flush();
		return fbe;
	}



	
	
	}

	



