package com.cg.dao;

import java.util.List;

import com.cg.entities.FlightBookEntity;


public interface BookingDao {
	
	public int  cancelbookingdetails( int  booking_Id);
	public  List<FlightBookEntity> viewbookingdetails(int booking_id);
	public abstract List<FlightBookEntity> loadAll();
	public FlightBookEntity booking(FlightBookEntity fbe);
	
}
