package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.FlightBookEntity;
import com.cg.service.BookingService;

@Controller
public class FlightController {
	@Autowired
	private BookingService bookingService;

	@RequestMapping("/index")
	public String getMoviePage(Model model) {
		return "index";
	}
	
	
	@RequestMapping("/conformbooking")
	public String getHomePage(Model model){
		model.addAttribute("bookList",bookingService.loadAll());
		model.addAttribute("flight",new FlightBookEntity());
		return "conformbooking";
	}
	
	@RequestMapping(value="/conformbooking",method=RequestMethod.POST)
	public String booking(@ModelAttribute("flight")FlightBookEntity fbe, Model model){
		fbe=bookingService.booking(fbe);
		model.addAttribute("message","Booking with id "+fbe.getBooking_Id()+" added successfully!");
		return "conformbooking";
		
	}

	@RequestMapping("/cancel")
	public String cancelbookingdetails(Model model) {
		model.addAttribute("FlightBookEntity", new FlightBookEntity());
		return "cancel";
	}

	@RequestMapping(value = "/cancel1")
	public String deleteflight(
			@ModelAttribute("FlightBookEntity") FlightBookEntity f, Model model) {
		int booking_id = f.getBooking_Id();

		int bid = bookingService.cancelbookingdetails(booking_id);

		if (bid != 0) {

			model.addAttribute("message1", bid + " details deleted");

			System.out.println("success");

			return "cancel";
		}

		if (bid == 0) {
			model.addAttribute("msg", "No flight details on this id");
			System.out.println("cancel");

			return "cancel";
		}
		return "cancel";
	}

	@RequestMapping("/viewform")
	public String viewbookingdetails(Model model) {
		model.addAttribute("FlightBookEntity", new FlightBookEntity());
		return "viewform";
	}

	@RequestMapping(value = "/view1")
	public String viewbookingdetails(@ModelAttribute("FlightBookEntity") FlightBookEntity f, Model model) {
		int booking_id = f.getBooking_Id();
		List<FlightBookEntity> bid = bookingService.viewbookingdetails(booking_id);
		model.addAttribute("userDetails",bid);
		
		if (bid!=null)	
			{
			model.addAttribute("msg2",booking_id+ " details displayed");
            return "view";
			}
		if(bid==null) {
			 model.addAttribute("message2", booking_id+ "No flight details on this id");
			return "view";
		}
		return "view";
		
	}
		
	}


