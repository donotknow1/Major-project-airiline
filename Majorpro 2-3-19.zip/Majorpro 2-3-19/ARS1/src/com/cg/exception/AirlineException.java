package com.cg.exception;

public class AirlineException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AirlineException(String message) {
		super(message);
	}

	
	
	
	
}
