
package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.FlightBookEntity;
import com.cg.entities.FlightInfo;
import com.cg.entities.Users;
import com.cg.service.FlightService;

@Controller
public class AdminController 
{
	@Autowired
	private FlightService flightService;
	
	

	public AdminController() {
		super();
		
	}
//index page
	@RequestMapping(value="/index")
	public String prepareLogin(Model model)
	{	
		model.addAttribute("user", new Users());
       
		
		//model.addAttribute( );
		return "homePage";
	}
	
/*	@RequestMapping(value="/admin")
	public String adminLogin(Model model){
	    
		model.addAttribute("user", new Users());
		
		return "homePage";
	}   */

	@RequestMapping(value="/adminDetails", method=RequestMethod.POST)
	public String admin(@ModelAttribute("user")Users user,boolean a,Model model,BindingResult result){
	  
		a=flightService.adminLogin(user);
		
		String role=user.getRole();
	  
	  if(a==true){
		  if(role.equals("admin"))
		  return "loginSuccess";
		  if(result.hasErrors()){
		  if(role.equals("executive"))
			  return "executive";
	  }
	  }
		System.out.println("controller");
		model.addAttribute("invalid", "Invalid username or password");
		return "homePage";
		
	}  

	


	@RequestMapping(value="/executive")
	public String executive(Model model){
		
		return "executive";
	}
	

	@RequestMapping(value="/viewOccupancy")
	public String viewOccupancy(Model model){
		
		model.addAttribute("flightList",flightService.viewFlightOccupancy());
		model.addAttribute("flightInfo",new FlightInfo());
		
		return "view";
	}
	
	
	
	
	
	@RequestMapping("/insert")
	public String getHomePage1(Model model){
		model.addAttribute("flightList",flightService.loadAll());
		model.addAttribute("flightInfo",new FlightInfo());
		return "insert";
	}
	@RequestMapping(value="/insert1",method=RequestMethod.POST)
	public String flightinfo(@ModelAttribute("flightInfo")FlightInfo fi, Model model){
		fi=flightService.info(fi);
		model.addAttribute("message1","Booking with id "+fi.getFlightNo()+" added successfully!");
		return "bookingSuccess1";
	}

	
	
	@RequestMapping(value="view")
	public String toView(Model model){
		
		model.addAttribute("flight",new FlightInfo());
		
		return "redirect:/viewAllFlight.html";
	}
	
	
	@RequestMapping(value="viewAllFlight")
	public String viewPage(Model model){
		
		model.addAttribute("viewAllFlights", flightService.viewAllFlight());
		
		return "viewFlight";
	}
	
	
	
	
	
	
	
	

	@RequestMapping(value="/update")
	public String update(Model model){
		model.addAttribute("flightInfo",new FlightInfo());
		return "updateName";
	}
	
	@RequestMapping(value ="/updateName")
	public String updatename(@ModelAttribute("flightInfo")FlightInfo fl,Model model){
	int flightNo=fl.getFlightNo();
	String airline=fl.getAirline();
	
		int a=flightService.updateFlightName(flightNo,airline);
		System.out.println(a);
		model.addAttribute("message",a+" flight is updated");
		
		return "updateName1";
	}
	
/*	@RequestMapping(value="/updateName",method=RequestMethod.POST)
	public String updatename1( Model model,FlightInfo f){
		
		
		model.addAttribute("message2","Booking with id "+f.getFlightNo()+" added successfully!");
		return "updateName1";  
		
		
		
	}*/

	@RequestMapping(value="/customer")
	public String customerFlight(Model model)
	{
		 model.addAttribute("customerInfo", new FlightInfo());
		
		return "customer";
	}
	
	@RequestMapping(value="/customerDetails")
	public String customerRequest(@ModelAttribute("customerInfo")FlightInfo customer,Model model) 
	{
	model.addAttribute("customerDetails", flightService.getFlightDetails(customer));
	
	
	return "customerInfo";
	}
	
	@RequestMapping(value="/details")
	public String bookingInfo(@RequestParam("dep")String dep,@RequestParam("arr")String arr,@RequestParam("ddate")String depdate,@RequestParam("adate")String arrdate,@RequestParam("ffair")int ffair,@RequestParam("bfair")int bfair,Model model){
		
		model.addAttribute("dep",dep);
		model.addAttribute("arr",arr);
		model.addAttribute("ddate",depdate);
		model.addAttribute("adate",arrdate);
		model.addAttribute("ffair",ffair);
		model.addAttribute("bfair",bfair);
		model.addAttribute("bookF",new FlightBookEntity());
		return "bookingForm";
	}
	
	@RequestMapping(value="/book")
	public String bookConfirm(@ModelAttribute("bookF")FlightBookEntity f,Model model){
		FlightBookEntity f1=new FlightBookEntity();
        String creditCard=f.getCredit_Card_Info();
		String classType=f.getClass_Type();
		String email=f.getCust_Email();
		String destCity=f.getDest_City();
		String srcCity=f.getSrc_City();
		int pass=f.getNo_Of_Passengers();
		int ffare=f.getFirstfare();
		int bfare=f.getBussfare();
		if(classType.equals("firstClass"))
		{
			f1.setTotal_Fare(pass*ffare);
		}
		if(classType.equals("bussClass"))
		{
			f1.setTotal_Fare(pass*bfare);
		}
		f1.setClass_Type(classType);
		f1.setCredit_Card_Info(creditCard);
		f1.setCust_Email(email);
		f1.setDest_City(destCity);
		f1.setSrc_City(srcCity);
		f1.setNo_Of_Passengers(pass);
		
		
	    int bookingId=flightService.bookingFlight(f1);
		model.addAttribute("id",bookingId );
		return "bookingSuccess";
	}
}
	
	
	