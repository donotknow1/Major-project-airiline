package com.cg.entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


//import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="FLIGHTINFO")
public class FlightInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	//@NotEmpty(message = "The above field must not be blank.")
	@NotNull
	//@Column(name="FLIGHTNO")
	private int flightNo;
	//@Column(name="AIRLINE")
	private String airline;
	//@Column(name="DEP_CITY")
	private String depCity;
	//@Column(name="ARR_CITY")
	private String arrCity;
	//@Column(name="DEP_DATE")
	private String depdate;
	//@Column(name="ARR_DATE")
	private String arrDate;
	//@Column(name="DEP_TIME")
	private String depTime;
	//@Column(name="ARR_TIME")
	private String arrTime;
	//@NotEmpty(message = "The above field must not be blank.")
	//@Column(name="FIRSTSEATS")
	@NotNull
	private int firstSeats;
	//@NotEmpty(message = "The above field must not be blank.")
	//@Column(name="FIRSTSEATSFARE")
	@NotNull
	private int firstFair;
	//@NotEmpty(message = "The above field must not be blank.")
	//@Column(name="BUSSSEATS")
	@NotNull
	private int bussSeats;
	//@Column(name="BUSSSEATSFARE")
	@NotNull
	private int bussFair;
	
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDepCity() {
		return depCity;
	}
	public void setDepCity(String depCity) {
		this.depCity = depCity;
	}
	public String getArrCity() {
		return arrCity;
	}
	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}
	public String getDepdate() {
		return depdate;
	}
	public void setDepdate(String depdate) {
		this.depdate = depdate;
	}
	public String getArrDate() {
		return arrDate;
	}
	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}
	public String getDepTime() {
		return depTime;
	}
	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	
	public int getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}
	public int getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}
	public int getFirstFair() {
		return firstFair;
	}
	public void setFirstFair(int firstFair) {
		this.firstFair = firstFair;
	}
	public int getBussSeats() {
		return bussSeats;
	}
	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}
	public int getBussFair() {
		return bussFair;
	}
	public void setBussFair(int bussFair) {
		this.bussFair = bussFair;
	}

	

}
