package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entities.FlightBookEntity;
import com.cg.entities.Users;
import com.cg.dao.FlightDao;
import com.cg.entities.FlightInfo;

@Service
@Transactional
public class FlightServiceImpl implements FlightService{

	@Autowired
	private FlightDao flightDao;
	
	
	@Override
	public List<FlightInfo> loadAll() {
		return flightDao.loadAll();
	}

	@Override
	public FlightInfo info(FlightInfo fi) {
		
		return flightDao.info(fi);
	}

	@Override
	public FlightInfo viewdetails(int flightNo){
		
		return flightDao.viewdetails(flightNo);
	}

	@Override
	public int updateFlightName(int flightNo, String airline) {
		return flightDao.updateFlightName(flightNo, airline);
	}

	@Override
	public List<FlightInfo> viewAllFlight() {
		
		
		return flightDao.viewAllFlight();
	}
	
	@Override
	public boolean adminLogin(Users user) {
		
		return flightDao.adminLogin(user);
	}

	@Override
	public List<FlightInfo> viewFlightOccupancy() {
		
		return flightDao.viewFlightOccupancy();
	}

	@Override
	public List<FlightInfo> getFlightDetails(FlightInfo customer) {
		
		return flightDao.getFlightDetails(customer);
	}

	@Override
	public int bookingFlight(FlightBookEntity f1) {
		
		return flightDao.bookingFlight(f1);
	}

	
}
