package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;






import com.cg.entities.FlightBookEntity;
import com.cg.entities.Users;
import com.cg.entities.FlightInfo;

@Repository
public class FlightDaoImpl implements FlightDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean adminLogin(Users user) {
		String un=user.getUserName();
		System.out.println("cust:"+un);
		String pwd=user.getPassword();
		String role=user.getRole();
		System.out.println("cust role :"+role);
		Users users=new Users();
		
		String qry="SELECT u FROM Users u WHERE u.userName=:puser";
		TypedQuery<Users> query=entityManager.createQuery(qry,Users.class);
		query.setParameter("puser", un);
		try{
			
			 users=query.getSingleResult();
			
		}catch(NoResultException e){
		    System.out.println(users.getUserName());
			System.out.println("catch");
			return false;
		}
		System.out.println(users.getRole()+" rep");
		String un1=users.getUserName();
		String pwd1=users.getPassword();
		String role1=users.getRole();
		if(role1.equals(role)){
		if(un.equals(un1) && pwd.equals(pwd1))
		{
		return true;
		}
		}
		System.out.println("dao");
		return false;
	}
	
	
	
	

	@Override
	public List<FlightInfo> loadAll() {
		TypedQuery<FlightInfo>query1=entityManager.createQuery("SELECT c FROM FlightInfo c",FlightInfo.class);
		return query1.getResultList();
	}

	@Override
	public FlightInfo info(FlightInfo fi) {
		entityManager.persist(fi);
		entityManager.flush();
		return fi;
	}

	@Override
	public FlightInfo viewdetails(int flightNo) {
		String str="SELECT c FROM FlightInfo c WHERE c.flightNo=:pno";
		TypedQuery<FlightInfo> query2=entityManager.createQuery(str,FlightInfo.class);
		query2.setParameter("pno", flightNo);
		return query2.getSingleResult();
	}

	@Override
	public int updateFlightName(int flightNo, String airline) {
		String str1="UPDATE FlightInfo AS c SET c.airline=:pname WHERE c.flightNo=:pno";
		Query query3=entityManager.createQuery(str1);
		query3.setParameter("pname", airline);
		query3.setParameter("pno", flightNo); 

		return query3.executeUpdate();
	}
	/* em.createQuery(
		        "UPDATE Phone p SET p.number = "
		        + "CONCAT('0',SUBSTRING(p.number,"
		        + "LOCATE(p.number, '-'), 4)), p.type = 'Business' ")
		        .executeUpdate();*/

	@Override
	public List<FlightInfo> viewAllFlight() {
		
		TypedQuery<FlightInfo> queryF=entityManager.createQuery("SELECT f FROM FlightInfo f",FlightInfo.class);
		
		return queryF.getResultList();
	}





	@Override
	public List<FlightInfo> viewFlightOccupancy() {
		
		TypedQuery<FlightInfo> execQuery=entityManager.createQuery("SELECT c FROM FlightInfo c",FlightInfo.class);
		
		return execQuery.getResultList();
	}





	@Override
	public List<FlightInfo> getFlightDetails(FlightInfo customer) {
		
		String qry="SELECT f FROM FlightInfo f WHERE f.arrCity=:parr AND f.depCity=:pdep AND f.depdate=:pdate";
		
		TypedQuery<FlightInfo> customerDetails=entityManager.createQuery(qry,FlightInfo.class);
		customerDetails.setParameter("parr", customer.getArrCity());
		customerDetails.setParameter("pdep", customer.getDepCity());
		customerDetails.setParameter("pdate", customer.getDepdate());

		return customerDetails.getResultList();
	}





	@Override
	public int bookingFlight(FlightBookEntity f1) {
		
		entityManager.persist(f1);
		entityManager.flush();
		
		return f1.getBooking_Id();
	}
		 
	
	
	
	
}
//UPDATE FLIGHT_INFORMATION SET AIRLINE=? WHERE FLIGHTNO=?