package com.cg.dao;

import java.util.List;

import com.cg.entities.FlightBookEntity;
import com.cg.entities.Users;
import com.cg.entities.FlightInfo;

public interface FlightDao {
	
	
public abstract List<FlightInfo> loadAll();
	
	public FlightInfo info(FlightInfo fi);
	public FlightInfo viewdetails(int flightNo);
	public int updateFlightName(int flightNo, String airline);

	public abstract List<FlightInfo> viewAllFlight();

	boolean adminLogin(Users user);

	public abstract List<FlightInfo> viewFlightOccupancy();

	public abstract List<FlightInfo> getFlightDetails(FlightInfo customer);

	public abstract int bookingFlight(FlightBookEntity f1);
}
